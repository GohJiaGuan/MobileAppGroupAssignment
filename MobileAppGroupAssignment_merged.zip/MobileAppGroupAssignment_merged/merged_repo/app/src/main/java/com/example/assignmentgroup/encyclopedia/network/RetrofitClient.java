package com.example.assignmentgroup.encyclopedia.network;

import java.util.concurrent.TimeUnit;

import com.example.assignmentgroup.BuildConfig;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    // Google's Generative Language API (Gemini). Model name lives in
    // GeminiApiService (currently gemini-3.1-flash-lite) - see that file for
    // notes on why this needs occasional updating as Google retires old models.
    private static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta/";

    private static Retrofit retrofit;

    /** Read from local.properties -> app/build.gradle -> BuildConfig, never hard-coded here. */
    public static String getApiKey() {
        return BuildConfig.GEMINI_API_KEY;
    }

    public static boolean hasApiKey() {
        String key = getApiKey();
        return key != null && !key.trim().isEmpty();
    }

    public static GeminiApiService getGeminiApiService() {
        if (retrofit == null) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BASIC);

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .readTimeout(20, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(GeminiApiService.class);
    }
}
