package com.example.assignmentgroup.encyclopedia.network;

import com.example.assignmentgroup.encyclopedia.model.GeminiRequest;
import com.example.assignmentgroup.encyclopedia.model.GeminiResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

/**
 * Real generative-AI endpoint for the Ask AI Assistant, using Google's Gemini API.
 * This is what actually answers free-form questions directly (not a fixed/canned
 * answer) - fulfils the assignment's external web-service requirement too.
 *
 * Model: gemini-3.1-flash-lite - Google's current stable, low-cost Flash model
 * (fast free-tier friendly). Gemini 1.0/1.5/2.0 have all been shut down by Google
 * and now return HTTP 404 - if you see the chat silently falling back to local
 * article text, check that the model name here hasn't gone stale again; see
 * https://ai.google.dev/gemini-api/docs/changelog for the current model list.
 *
 * Get a free API key from https://aistudio.google.com/apikey and put it in
 * local.properties as GEMINI_API_KEY=xxxxx (see RetrofitClient / README).
 */
public interface GeminiApiService {

    @POST("models/gemini-3.1-flash-lite:generateContent")
    Call<GeminiResponse> generateContent(@Header("x-goog-api-key") String apiKey, @Body GeminiRequest request);
}
